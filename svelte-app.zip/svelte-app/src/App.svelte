<script>
	var arr = [{
		task: "complete svelte to do list",
		date: "09/june/2023"
	}];
	var task;
	var date;
	function display_task_and_date(){
		arr = [...arr, {task:task,date:date}];
		task = "";
		date = undefined;
		
		

	}
	var search_date;
	var temp;
	function change_search_date(){
		search_date = temp;
		temp = undefined;
	}
</script>
<main>
	
<h1 id = "heading">
	TODO  APP
	<hr>
	
	
		
	
</h1>
	<p>
		description -:
	</p>
	<textarea name = "describe_task" style="width:100vw;height:10vw; font-size:15px;" placeholder="what do you need to do? " bind:value = {task}  ></textarea> 
	<p>
		Due Date
	</p>
<div>
	<input type="date" name="dateInput" id="dateInput" bind:value={date}>
</div>
	<div>
		<button id ="add-task-button" type = "submit" on:click={display_task_and_date}>

				<h1 style = "margin : 0">
					+
			<span style="font-size:2rem;margin:0;">Add Task</span> 
					
			</h1>

		</button>
	</div>
	{#each arr as tasks }
	    <h1>{tasks.task}</h1>    <h1>{tasks.date}</h1>

	{/each}

	<hr>
	<br>
	<br>
	<h1>Search the tasks</h1>
	<input type="date" id = "search_date" bind:value={temp}>
	<button on:click={change_search_date}>search task</button>
	{#each arr as tasks }
		{#if tasks.date == search_date }
	    <h1>{tasks.task}</h1>    <h1>{tasks.date}</h1>
		{/if}

	{/each}

</main>

<style>
	#heading{
		text-align:center;
	}
	
	#add-task-button{
		background-color:black;
		color:white;
	}

</style>